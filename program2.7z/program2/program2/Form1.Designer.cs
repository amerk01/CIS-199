﻿namespace program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.plan1Rad = new System.Windows.Forms.RadioButton();
            this.plan2Rad = new System.Windows.Forms.RadioButton();
            this.plan3Rad = new System.Windows.Forms.RadioButton();
            this.incomeLbl = new System.Windows.Forms.Label();
            this.incomeTxt = new System.Windows.Forms.TextBox();
            this.calcBtn = new System.Windows.Forms.Button();
            this.planBaseRad = new System.Windows.Forms.RadioButton();
            this.dueLbl = new System.Windows.Forms.Label();
            this.margLbl = new System.Windows.Forms.Label();
            this.dueOutLbl = new System.Windows.Forms.Label();
            this.rateOutLbl = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.planBaseRad);
            this.groupBox1.Controls.Add(this.plan3Rad);
            this.groupBox1.Controls.Add(this.plan2Rad);
            this.groupBox1.Controls.Add(this.plan1Rad);
            this.groupBox1.Location = new System.Drawing.Point(150, 532);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(539, 308);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // plan1Rad
            // 
            this.plan1Rad.AutoSize = true;
            this.plan1Rad.Location = new System.Drawing.Point(7, 35);
            this.plan1Rad.Name = "plan1Rad";
            this.plan1Rad.Size = new System.Drawing.Size(150, 41);
            this.plan1Rad.TabIndex = 0;
            this.plan1Rad.TabStop = true;
            this.plan1Rad.Text = "Plan 1";
            this.plan1Rad.UseVisualStyleBackColor = true;
            // 
            // plan2Rad
            // 
            this.plan2Rad.AutoSize = true;
            this.plan2Rad.Location = new System.Drawing.Point(7, 93);
            this.plan2Rad.Name = "plan2Rad";
            this.plan2Rad.Size = new System.Drawing.Size(152, 41);
            this.plan2Rad.TabIndex = 1;
            this.plan2Rad.TabStop = true;
            this.plan2Rad.Text = "Plan 2";
            this.plan2Rad.UseVisualStyleBackColor = true;
            // 
            // plan3Rad
            // 
            this.plan3Rad.AutoSize = true;
            this.plan3Rad.Location = new System.Drawing.Point(7, 153);
            this.plan3Rad.Name = "plan3Rad";
            this.plan3Rad.Size = new System.Drawing.Size(152, 41);
            this.plan3Rad.TabIndex = 2;
            this.plan3Rad.TabStop = true;
            this.plan3Rad.Text = "Plan 3";
            this.plan3Rad.UseVisualStyleBackColor = true;
            // 
            // incomeLbl
            // 
            this.incomeLbl.AutoSize = true;
            this.incomeLbl.Location = new System.Drawing.Point(12, 149);
            this.incomeLbl.Name = "incomeLbl";
            this.incomeLbl.Size = new System.Drawing.Size(305, 37);
            this.incomeLbl.TabIndex = 4;
            this.incomeLbl.Text = "Enter Yearly Income";
            // 
            // incomeTxt
            // 
            this.incomeTxt.Location = new System.Drawing.Point(503, 142);
            this.incomeTxt.Name = "incomeTxt";
            this.incomeTxt.Size = new System.Drawing.Size(186, 44);
            this.incomeTxt.TabIndex = 5;
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(351, 930);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(314, 97);
            this.calcBtn.TabIndex = 6;
            this.calcBtn.Text = "Calculate Tax";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // planBaseRad
            // 
            this.planBaseRad.AutoSize = true;
            this.planBaseRad.Location = new System.Drawing.Point(7, 209);
            this.planBaseRad.Name = "planBaseRad";
            this.planBaseRad.Size = new System.Drawing.Size(206, 41);
            this.planBaseRad.TabIndex = 3;
            this.planBaseRad.TabStop = true;
            this.planBaseRad.Text = "Base Plan";
            this.planBaseRad.UseVisualStyleBackColor = true;
            // 
            // dueLbl
            // 
            this.dueLbl.AutoSize = true;
            this.dueLbl.Location = new System.Drawing.Point(180, 214);
            this.dueLbl.Name = "dueLbl";
            this.dueLbl.Size = new System.Drawing.Size(137, 37);
            this.dueLbl.TabIndex = 7;
            this.dueLbl.Text = "Tax Due";
            // 
            // margLbl
            // 
            this.margLbl.AutoSize = true;
            this.margLbl.Location = new System.Drawing.Point(102, 277);
            this.margLbl.Name = "margLbl";
            this.margLbl.Size = new System.Drawing.Size(215, 37);
            this.margLbl.TabIndex = 8;
            this.margLbl.Text = "Marginal Rate";
            // 
            // dueOutLbl
            // 
            this.dueOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dueOutLbl.Location = new System.Drawing.Point(503, 214);
            this.dueOutLbl.Name = "dueOutLbl";
            this.dueOutLbl.Size = new System.Drawing.Size(213, 37);
            this.dueOutLbl.TabIndex = 9;
            // 
            // rateOutLbl
            // 
            this.rateOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rateOutLbl.Location = new System.Drawing.Point(503, 276);
            this.rateOutLbl.Name = "rateOutLbl";
            this.rateOutLbl.Size = new System.Drawing.Size(213, 37);
            this.rateOutLbl.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1524, 1105);
            this.Controls.Add(this.rateOutLbl);
            this.Controls.Add(this.dueOutLbl);
            this.Controls.Add(this.margLbl);
            this.Controls.Add(this.dueLbl);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.incomeTxt);
            this.Controls.Add(this.incomeLbl);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton planBaseRad;
        private System.Windows.Forms.RadioButton plan3Rad;
        private System.Windows.Forms.RadioButton plan2Rad;
        private System.Windows.Forms.RadioButton plan1Rad;
        private System.Windows.Forms.Label incomeLbl;
        private System.Windows.Forms.TextBox incomeTxt;
        private System.Windows.Forms.Button calcBtn;
        private System.Windows.Forms.Label dueLbl;
        private System.Windows.Forms.Label margLbl;
        private System.Windows.Forms.Label dueOutLbl;
        private System.Windows.Forms.Label rateOutLbl;
    }
}

