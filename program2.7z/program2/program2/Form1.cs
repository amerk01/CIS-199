﻿//S5547
//due march 3 2020
//cis 199 75
//tax calculator
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcBtn_Click(object sender, EventArgs e)
        {
            int dependent = 0; //variable that controls the switch statement
            double income = double.Parse(incomeTxt.Text); //income that is input by user
            double margRate=0; // marginal tax rate
            double taxDue=0; //tax amount due

            //constants plan 1
            const double P1brack1 = 500000; //highest bracket range
            const double P1brack2 = 200001; //next highest
            const double P1brack3 = 157501; //next highest
            const double P1brack4 = 82501; // next highest
            const double P1brack5 = 38701; // next highest
            const double P1brack6 = 9526; //lowest bracket limit
            const double P1marB1 = .396; //highest marginal tax
            const double P1marB2 = .35; //next highest
            const double P1marB3 = .33;//next highest
            const double P1marB4 = .28;//next highest
            const double P1marB5 = .25;//next highest
            const double P1marB6 = .15;//next highest
            const double P1marB7 = .10;//lowest marginal tax rate

            //constants plan 2
            const double P2brack1 = 10000000; //highest bracket range
            const double P2brack2 = 2000001; //next highest
            const double P2brack3 = 500001; //next highest
            const double P2brack4 = 250001; // next highest
            const double P2brack5 = 200001; // next highest
            const double P2brack6 = 157501; // next highest
            const double P2brack7 = 82501;//next highest
            const double P2brack8 = 38701;//next highest
            const double P2brack9 = 9526;//lowest bracket top range
            const double P2marB1 = .52; //highest marginal tax
            const double P2marB2 = .50; //next highest
            const double P2marB3 = .45;//next highest
            const double P2marB4 = .40;//next highest
            const double P2marB5 = .35;//next highest
            const double P2marB6 = .33;//next highest
            const double P2marB7 = .24;//next highest
            const double P2marB8 = .22;//next highest
            const double P2marB9 = .12;//next highest
            const double P2marB10 = .10;//lowest marginal tax rate

            //plan 3 constants are the same as plan 1

            //base plan constants
            const double PBbrack1 = 510301;
            const double PBbrack2 = 204101;
            const double PBbrack3 = 160726;
            const double PBbrack4 = 84201;
            const double PBbrack5 = 39476;
            const double PBbrack6 = 9701;
            const double PBmarB1 = .37;
            const double PBmarB2 = .35;
            const double PBmarB3 = .32;
            const double PBmarB4 = .24;
            const double PBmarB5 = .22;
            const double PBmarB6 = .12;
            const double PBmarB7 = .10;


            //the following if statements determine marginal rate
            if (plan1Rad.Checked)
            {
                dependent = 2;
                if (income >= P1brack1)
                    margRate = P1marB1;
                else if (income >= P1brack2)
                    margRate = P1marB2;
                else if (income >= P1brack3)
                    margRate = P1marB3;
                else if (income >= P1brack4)
                    margRate = P1marB4;
                else if (income >= P1brack5)
                    margRate = P1marB5;
                else if (income >= P1brack6)
                    margRate = P1marB6;
                else 
                    margRate = P1marB7;
            }
            else if (plan2Rad.Checked)
            {
                dependent = 3;
                if (income >= P2brack1)
                    margRate = P2marB1;
                else if (income >= P2brack2)
                    margRate = P2marB2;
                else if (income >= P2brack3)
                    margRate = P2marB3;
                else if (income >= P2brack4)
                    margRate = P2marB4;
                else if (income >= P2brack5)
                    margRate = P2marB5;
                else if (income >= P2brack6)
                    margRate = P2marB6;
                else if (income >= P2brack7)
                    margRate = P2marB7;
                else if (income >= P2brack8)
                    margRate = P2marB8;
                else if (income >= P2brack9)
                    margRate = P2marB9;
                else
                    margRate = P2marB10;
            }
            else if (plan3Rad.Checked)
            {
                dependent = 4;
                if (income >= P1brack1)
                    margRate = P1marB1;
                else if (income >= P1brack2)
                    margRate = P1marB2;
                else if (income >= P1brack3)
                    margRate = P1marB3;
                else if (income >= P1brack4)
                    margRate = P1marB4;
                else if (income >= P1brack5)
                    margRate = P1marB5;
                else if (income >= P1brack6)
                    margRate = P1marB6;
                else
                    margRate = P1marB7;
            }
            else if (planBaseRad.Checked)
            {
                dependent = 1;
                if (income >= PBbrack1)
                    margRate = PBmarB1;
                else if (income >= PBbrack2)
                    margRate = PBmarB2;
                else if (income >= PBbrack3)
                    margRate = PBmarB3;
                else if (income >= PBbrack4)
                    margRate = PBmarB4;
                else if (income >= PBbrack5)
                    margRate = PBmarB5;
                else if (income >= PBbrack6)
                    margRate = PBmarB6;
                else
                    margRate = PBmarB7;
            }
            else MessageBox.Show("choose a plan!");

            //switch statment used to change between plan options
            //each of these while loops steps through starting at the top bracket, checks to see if any taxable income in said bracket, then decreases any amount taxed so it can step down to next bracket
            switch (dependent)
            {
                default:
                case 1:
                    while (income>0)
                    {
                        if (income >= PBbrack1)
                        {
                            taxDue += (income - PBbrack1) * PBmarB1;
                            income -= income - PBbrack1;
                        }

                        else if (income >= PBbrack2)
                        {
                            taxDue += ((income - PBbrack2) * PBmarB2);
                            income -= (income - PBbrack2);
                        }
                        else if (income >= PBbrack3)
                        {
                            taxDue += ((income - PBbrack3) * PBmarB3);
                            income -= (income - PBbrack3);
                        }
                        else if (income >= PBbrack4)
                        {
                            taxDue += ((income - PBbrack4) * PBmarB4);
                            income -= (income - PBbrack4);
                        }
                        else if (income >= PBbrack5)
                        {
                            taxDue += ((income - PBbrack5) * PBmarB5);
                            income -= (income - PBbrack5);
                        }
                        else if (income >= PBbrack6)
                        {
                            taxDue += ((income - PBbrack6) * PBmarB6);
                            income -= (income - PBbrack6);
                        }
                        else if (income > 0)
                        {
                            taxDue += ((income) * PBmarB7);
                            income = 0;
                        }
                    }
                    break;
                case 2:
                    while (income > 0)
                    {
                        if (income >= P1brack1)
                        {
                            taxDue += (income - P1brack1) * P1marB1;
                            income -= (income - P1brack1);
                        }

                        else if (income >= P1brack2)
                        {
                            taxDue += ((income - P1brack2) * P1marB2);
                            income -= (income - P1brack2);
                        }
                        else if (income >= P1brack3)
                        {
                            taxDue += ((income - P1brack3) * P1marB3);
                            income -= (income - P1brack3);
                        }
                        else if (income >= P1brack4)
                        {
                            taxDue += ((income - P1brack4) * P1marB4);
                            income -= (income - P1brack4);
                        }
                        else if (income >= P1brack5)
                        {
                            taxDue += ((income - P1brack5) * P1marB5);
                            income -= (income - P1brack5);
                        }
                        else if (income >= P1brack6)
                        {
                            taxDue += ((income - P1brack6) * P1marB6);
                            income -= (income - P1brack6);
                        }
                        else if (income > 0)
                        {
                            taxDue += ((income) * P1marB7);
                            income = 0;
                        }
                    }
                    break;
                case 3:
                    //adds 4 percent tax to all income over 29000
                    if (income > 29000)
                        taxDue += .04 * (income - 29000);
                    while (income > 0)f
                    {
                        if (income >= P2brack1)
                        {
                            taxDue += (income - P2brack1) * P2marB1;
                            income -= income - P2brack1;
                        }

                        else if (income >= P2brack2)
                        {
                            taxDue += ((income - P2brack2) * P2marB2);
                            income -= (income - P2brack2);
                        }
                        else if (income >= P2brack3)
                        {
                            taxDue += ((income - P2brack3) * P2marB3);
                            income -= (income - P2brack3);
                        }
                        else if (income >= P2brack4)
                        {
                            taxDue += ((income - P2brack4) * P2marB4);
                            income -= (income - P2brack4);
                        }
                        else if (income >= P2brack5)
                        {
                            taxDue += ((income - P2brack5) * P2marB5);
                            income -= (income - P2brack5);
                        }
                        else if (income >= P2brack6)
                        {
                            taxDue += ((income - P2brack6) * P2marB6);
                            income -= (income - P2brack6);
                        }
                        else if (income >= P2brack7)
                        {
                            taxDue += ((income - P2brack7) * P2marB7);
                            income -= (income - P2brack7);
                        }
                        else if (income >= P2brack8)
                        {
                            taxDue += ((income - P2brack8) * P2marB8);
                            income -= (income - P2brack8);
                        }
                        else if (income >= P2brack9)
                        {
                            taxDue += ((income - P2brack9) * P2marB9);
                            income -= (income - P2brack9);
                        }
                        else if (income > 0)
                        {
                            taxDue += income * P2marB10;
                            income = 0;
                        }
                    }
                    break;
                case 4:
                    while (income > 0)
                    {
                        if (income >= P1brack1)
                        {
                            taxDue += (income - P1brack1) * P1marB1;
                            income -= income - P1brack1;
                        }

                        else if (income >= P1brack2)
                        {
                            taxDue += ((income - P1brack2) * P1marB2);
                            income -= (income - P1brack2);
                        }
                        else if (income >= P1brack3)
                        {
                            taxDue += ((income - P1brack3) * P1marB3)*.9;
                            income -= (income - P1brack3);
                        }
                        else if (income >= P1brack4)
                        {
                            taxDue += ((income - P1brack4) * P1marB4)*.9;
                            income -= (income - P1brack4);
                        }
                        else if (income >= P1brack5)
                        {
                            taxDue += ((income - P1brack5) * P1marB5)*.9;
                            income -= (income - P1brack5);
                        }
                        else if (income >= P1brack6)
                        {
                            taxDue += ((income - P1brack6) * P1marB6)*.9;
                            income -= (income - P1brack6);
                        }
                        else if (income > 0)
                        {
                            taxDue += ((income) * P1marB7)*.9;
                            income = 0;
                        }
                    }
                    break;
            }
            
            dueOutLbl.Text = ($"{taxDue:C}");
            rateOutLbl.Text = ($"{margRate:P}");
        }
    }
}
