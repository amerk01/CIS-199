﻿//Grade id S5547
//CIS199-75
//Due april 17
//program 4

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace program_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //test packages created here
            GroundPackage gp1 = new GroundPackage(20202, 30303, 12, 34, 21, 5);
            GroundPackage gp2 = new GroundPackage(20302, 30303, 42, 34, 21, 1.5);
            GroundPackage gp3 = new GroundPackage(10242, 40303, 2, 34, 21, 5);
            GroundPackage gp4 = new GroundPackage(60202, 20303, 42, 34, 21, 2);
            GroundPackage gp5 = new GroundPackage(73202, 30305, 2, 4, 20, 1);
            GroundPackage gp6 = new GroundPackage(20602, 90303, 12, 74, 21, 5);

            //above objects are put in to an array
            GroundPackage[] allPacks = { gp1, gp2, gp3, gp4, gp5, gp6 };

            //displays all packages
            //pre must have array of packages
            //post nothing changes, just displays packages
            void DisplayPackages(GroundPackage[] arrayOfPs)
            {
                for (int i = 0; i < arrayOfPs.Length; i++)
                {
                    WriteLine($"Shipping Cost: {arrayOfPs[i].CalcCost():C}\n{arrayOfPs[i]}");
                }
            }
            DisplayPackages(allPacks);

            //changes all packages weight and displays again
            for (int i=0; i<allPacks.Length; i++)
            {
                allPacks[i].Weight = 30;
            }
            DisplayPackages(allPacks);

        }
    }
    public class GroundPackage
    {
        //Constants used for cost calculation
        public const double SIZE_COST_FACTOR = 0.20;
        public const double WEIGHT_COST_FACTOR = 0.35;


        //outgoing zipcode, destination zip code and distance backing fields
        private int oZip, dZip, zoneDist;
        //length width height and weight of package backing fields
        private double len, wid, height, weight;
        //Properties for above fields are below
        public int OZip
        {
            get
            {
                return oZip;
            }
            set
            {
                if (value >= 0 && value <= 99999)
                {
                    oZip = value;
                }
                else oZip = 40204;
            }
        }
        public int DZip
        {
            get
            {
                return dZip;
            }
            set
            {
                if (value >= 0 && value <= 99999)
                {
                    dZip = value;
                }
                else dZip = 60606;
            }
        }
        public double Len
        {
            get
            {
                return len;
            }
            set
            {
                if (value > 0)
                    len = value;
                else
                    len = 12;
            }
        }
        public double Wid
        {
            get
            {
                return wid;
            }
            set
            {
                if (value > 0)
                    wid = value;
                else
                    wid = 12;
            }
        }
        public double Height
        {
            get
            {
                return height;
            }
            set
            {
                if (height > 0)
                    height = value;
                else
                    height = 12;
            }
        }
        public double Weight
        {
            get
            {
                return weight;
            }
            set
            {
                if (value > 0)
                    weight = value;
                else
                    weight = 12;
            }
        }
        public int ZoneDist
        {
            get
            {
                zoneDist = Math.Abs((OZip / 10000) - (DZip / 100000));
                return zoneDist;
            }
        }

        //methods

        //pre none
        //post cost is set and returned
        public double CalcCost()
        {
            return SIZE_COST_FACTOR * (Len + Wid + Height) + WEIGHT_COST_FACTOR * (ZoneDist + 1) * (Weight);
        }

        //pre none
        //post object properties are used to return a string of all info
        public override string ToString()
        {
            return $"Origin Zip Code: {OZip} " + Environment.NewLine + $"Destination Zip Code: {DZip}" + Environment.NewLine +
                $"Length: {Len}" + Environment.NewLine + $"Width: {Wid}" + Environment.NewLine + $"Height: {Height}" + Environment.NewLine +
                $"Weight: {Weight}" + Environment.NewLine + $"Zone Distance: {ZoneDist}" + Environment.NewLine;
        }

        //constructor
        public GroundPackage(int oZip, int dZip, double len, double wid, double height, double weight)
        {
            this.OZip = oZip;
            this.DZip = dZip;
            this.Len = len;
            this.Wid = wid;
            this.Height = height;
            this.Weight = weight;


        }
    }
}

