﻿//Grading ID S5547
//Lab 2
//Due Feb 2 2020
//Section 75
//This program is a gui that allows users to type a price of a meal into a text box
//and outputs different tips based on different percentages of the total.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //sets up constants to be used in tip calculation, starting with 15%, then 18% and finally
            //20% tips
            const double tipRate1 = 0.15;
            const double tipRate2 = 0.18;
            const double tipRate3 = 0.2;

            //gets price entered in text box, defines and calculates the three tips by multiplying price with tiprate
            double price = double.Parse(priceBox.Text);
            double tip15 = price * tipRate1;
            double tip18 = price * tipRate2;
            double tip20 = price * tipRate3;
            //changes the tips into strings in currency format, then sets the text of the output boxes to those values
            output15Lbl.Text = tip15.ToString("C");
            output18Lbl.Text = tip18.ToString("C");
            output20Lbl.Text = tip20.ToString("C");
        }
    }
}
