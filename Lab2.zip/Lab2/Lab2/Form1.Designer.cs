﻿namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.entPriceLbl = new System.Windows.Forms.Label();
            this.priceBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.output15Lbl = new System.Windows.Forms.Label();
            this.output18Lbl = new System.Windows.Forms.Label();
            this.output20Lbl = new System.Windows.Forms.Label();
            this.calcBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // entPriceLbl
            // 
            this.entPriceLbl.AutoSize = true;
            this.entPriceLbl.Location = new System.Drawing.Point(173, 230);
            this.entPriceLbl.Name = "entPriceLbl";
            this.entPriceLbl.Size = new System.Drawing.Size(303, 37);
            this.entPriceLbl.TabIndex = 0;
            this.entPriceLbl.Text = "Enter price of meal: ";
            // 
            // priceBox
            // 
            this.priceBox.Location = new System.Drawing.Point(563, 230);
            this.priceBox.Name = "priceBox";
            this.priceBox.Size = new System.Drawing.Size(431, 44);
            this.priceBox.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(376, 598);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 37);
            this.label15.TabIndex = 2;
            this.label15.Text = "15%";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(374, 783);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(81, 37);
            this.label20.TabIndex = 3;
            this.label20.Text = "20%";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(376, 686);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 37);
            this.label18.TabIndex = 4;
            this.label18.Text = "18%";
            // 
            // output15Lbl
            // 
            this.output15Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.output15Lbl.Location = new System.Drawing.Point(563, 598);
            this.output15Lbl.Name = "output15Lbl";
            this.output15Lbl.Size = new System.Drawing.Size(160, 53);
            this.output15Lbl.TabIndex = 5;
            // 
            // output18Lbl
            // 
            this.output18Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.output18Lbl.Location = new System.Drawing.Point(563, 685);
            this.output18Lbl.Name = "output18Lbl";
            this.output18Lbl.Size = new System.Drawing.Size(160, 53);
            this.output18Lbl.TabIndex = 6;
            // 
            // output20Lbl
            // 
            this.output20Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.output20Lbl.Location = new System.Drawing.Point(563, 782);
            this.output20Lbl.Name = "output20Lbl";
            this.output20Lbl.Size = new System.Drawing.Size(160, 53);
            this.output20Lbl.TabIndex = 7;
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(1078, 598);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(326, 254);
            this.calcBtn.TabIndex = 8;
            this.calcBtn.Text = "Calculate Tip!";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1760, 1184);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.output20Lbl);
            this.Controls.Add(this.output18Lbl);
            this.Controls.Add(this.output15Lbl);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.priceBox);
            this.Controls.Add(this.entPriceLbl);
            this.Name = "Form1";
            this.Text = "Lab 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label entPriceLbl;
        private System.Windows.Forms.TextBox priceBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label output15Lbl;
        private System.Windows.Forms.Label output18Lbl;
        private System.Windows.Forms.Label output20Lbl;
        private System.Windows.Forms.Button calcBtn;
    }
}

