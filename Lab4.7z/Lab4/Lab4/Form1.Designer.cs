﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resBtn = new System.Windows.Forms.Button();
            this.gpaLbl = new System.Windows.Forms.Label();
            this.gpaTxt = new System.Windows.Forms.TextBox();
            this.scoreLbl = new System.Windows.Forms.Label();
            this.scoreTxt = new System.Windows.Forms.TextBox();
            this.resultLbl = new System.Windows.Forms.Label();
            this.resultDispLbl = new System.Windows.Forms.Label();
            this.acceptLbl = new System.Windows.Forms.Label();
            this.rejectLbl = new System.Windows.Forms.Label();
            this.acceptLblNum = new System.Windows.Forms.Label();
            this.rejectLblNum = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // resBtn
            // 
            this.resBtn.Location = new System.Drawing.Point(263, 180);
            this.resBtn.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.resBtn.Name = "resBtn";
            this.resBtn.Size = new System.Drawing.Size(56, 24);
            this.resBtn.TabIndex = 0;
            this.resBtn.Text = "Check Results";
            this.resBtn.UseVisualStyleBackColor = true;
            this.resBtn.Click += new System.EventHandler(this.resBtn_Click);
            // 
            // gpaLbl
            // 
            this.gpaLbl.AutoSize = true;
            this.gpaLbl.Location = new System.Drawing.Point(70, 73);
            this.gpaLbl.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.gpaLbl.Name = "gpaLbl";
            this.gpaLbl.Size = new System.Drawing.Size(57, 13);
            this.gpaLbl.TabIndex = 1;
            this.gpaLbl.Text = "Enter GPA";
            // 
            // gpaTxt
            // 
            this.gpaTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gpaTxt.Location = new System.Drawing.Point(141, 73);
            this.gpaTxt.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.gpaTxt.Name = "gpaTxt";
            this.gpaTxt.Size = new System.Drawing.Size(33, 20);
            this.gpaTxt.TabIndex = 2;
            // 
            // scoreLbl
            // 
            this.scoreLbl.AutoSize = true;
            this.scoreLbl.Location = new System.Drawing.Point(15, 99);
            this.scoreLbl.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.scoreLbl.Name = "scoreLbl";
            this.scoreLbl.Size = new System.Drawing.Size(113, 13);
            this.scoreLbl.TabIndex = 3;
            this.scoreLbl.Text = "Enter Admission Score";
            // 
            // scoreTxt
            // 
            this.scoreTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.scoreTxt.Location = new System.Drawing.Point(141, 99);
            this.scoreTxt.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.scoreTxt.Name = "scoreTxt";
            this.scoreTxt.Size = new System.Drawing.Size(33, 20);
            this.scoreTxt.TabIndex = 4;
            // 
            // resultLbl
            // 
            this.resultLbl.AutoSize = true;
            this.resultLbl.Location = new System.Drawing.Point(90, 134);
            this.resultLbl.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.resultLbl.Name = "resultLbl";
            this.resultLbl.Size = new System.Drawing.Size(37, 13);
            this.resultLbl.TabIndex = 5;
            this.resultLbl.Text = "Result";
            // 
            // resultDispLbl
            // 
            this.resultDispLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultDispLbl.Location = new System.Drawing.Point(139, 134);
            this.resultDispLbl.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.resultDispLbl.Name = "resultDispLbl";
            this.resultDispLbl.Size = new System.Drawing.Size(60, 16);
            this.resultDispLbl.TabIndex = 6;
            // 
            // acceptLbl
            // 
            this.acceptLbl.AutoSize = true;
            this.acceptLbl.Location = new System.Drawing.Point(57, 263);
            this.acceptLbl.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.acceptLbl.Name = "acceptLbl";
            this.acceptLbl.Size = new System.Drawing.Size(59, 13);
            this.acceptLbl.TabIndex = 7;
            this.acceptLbl.Text = "Accepted: ";
            // 
            // rejectLbl
            // 
            this.rejectLbl.AutoSize = true;
            this.rejectLbl.Location = new System.Drawing.Point(57, 300);
            this.rejectLbl.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.rejectLbl.Name = "rejectLbl";
            this.rejectLbl.Size = new System.Drawing.Size(56, 13);
            this.rejectLbl.TabIndex = 8;
            this.rejectLbl.Text = "Rejected: ";
            // 
            // acceptLblNum
            // 
            this.acceptLblNum.AutoSize = true;
            this.acceptLblNum.Location = new System.Drawing.Point(121, 263);
            this.acceptLblNum.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.acceptLblNum.Name = "acceptLblNum";
            this.acceptLblNum.Size = new System.Drawing.Size(0, 13);
            this.acceptLblNum.TabIndex = 9;
            // 
            // rejectLblNum
            // 
            this.rejectLblNum.AutoSize = true;
            this.rejectLblNum.Location = new System.Drawing.Point(123, 300);
            this.rejectLblNum.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.rejectLblNum.Name = "rejectLblNum";
            this.rejectLblNum.Size = new System.Drawing.Size(0, 13);
            this.rejectLblNum.TabIndex = 10;
            // 
            // Form1
            // 
            this.AcceptButton = this.resBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 385);
            this.Controls.Add(this.rejectLblNum);
            this.Controls.Add(this.acceptLblNum);
            this.Controls.Add(this.rejectLbl);
            this.Controls.Add(this.acceptLbl);
            this.Controls.Add(this.resultDispLbl);
            this.Controls.Add(this.resultLbl);
            this.Controls.Add(this.scoreTxt);
            this.Controls.Add(this.scoreLbl);
            this.Controls.Add(this.gpaTxt);
            this.Controls.Add(this.gpaLbl);
            this.Controls.Add(this.resBtn);
            this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button resBtn;
        private System.Windows.Forms.Label gpaLbl;
        private System.Windows.Forms.TextBox gpaTxt;
        private System.Windows.Forms.Label scoreLbl;
        private System.Windows.Forms.TextBox scoreTxt;
        private System.Windows.Forms.Label resultLbl;
        private System.Windows.Forms.Label resultDispLbl;
        private System.Windows.Forms.Label acceptLbl;
        private System.Windows.Forms.Label rejectLbl;
        private System.Windows.Forms.Label acceptLblNum;
        private System.Windows.Forms.Label rejectLblNum;
    }
}

