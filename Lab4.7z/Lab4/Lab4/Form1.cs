﻿//grading id s5547
//lab 4
//due feb 17
//cis 199 75
//checks to see if a students gpa and test scores are in range of acceptance to a college

//PLEASE NOTE if you are using a high res display, you might have to change your scaling in order for this form to work properly
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
        //these variables serve as counters to keep track of rejected and accepted applicants
        int accepted=0;
        int rejected=0;
        public Form1()
        {
            InitializeComponent();
        }
        
        //checks to see if the inputs are valid, then checks to see if scores are in acceptance range.
        private void resBtn_Click(object sender, EventArgs e)
        {
            //checks if inputs valid, and declares a GPA variable and a test score variable, named gpa and score
            if ((float.TryParse(gpaTxt.Text, out float gpa)) && (uint.TryParse(scoreTxt.Text, out uint score)))
            {
                if (gpa > 3.0 && score > 60)
                {
                    resultDispLbl.Text = "Accepted!";
                    accepted++;
                }
                else if (score > 80)
                {
                    resultDispLbl.Text = "Accepted!";
                    accepted++;
                }
                else
                {
                    resultDispLbl.Text = "Rejected";
                    rejected++;
                }
            }
            else MessageBox.Show("Invalid Inputs!");
            acceptLblNum.Text = accepted.ToString();
            rejectLblNum.Text = rejected.ToString();
        }
    }
}
